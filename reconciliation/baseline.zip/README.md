<!-- @format -->

# Antipolo City Disease Surveillance — Hybrid Forecast Dashboard

A Dash app that starts with a seven-disease synthetic sample, accepts real
DOH/PIDSR surveillance data for arbitrary disease labels, and forecasts each
uploaded disease with SARIMA-only and SARIMA + NNAR candidates. The production
forecast uses the simpler SARIMA-only candidate unless Hybrid improves aggregate
rolling-selection WAPE by at least 1.00 percentage point; a separate final
12-month holdout reports performance without guaranteeing future superiority.

## Package structure

```
app.py                          # entrypoint: wires app_instance + layout + callbacks together
dashboard/
  app_instance.py                # the shared Dash `app` object (breaks circular imports)
  config.py                      # sample diseases, model hyperparameters, thresholds
  styles.py                      # visual constants (fonts, colors, CSS-in-JS dicts)
  logging_config.py              # operator-facing logging (separate from the UI's own warnings)
  data/
    date_parser.py                # flexible dates -> canonical monthly observations
    mock_data.py                  # synthetic fallback generator
    pdf_converter.py              # offline text-PDF table conversion + audit report
    xlsx_parser.py                 # real DOH/PIDSR workbook parser
    validation.py                  # disease-label + numeric/range validation
    combine.py                     # finalizes an authoritative uploaded dataset
  modeling/
    series_utils.py                # monthly series shaping, train/test split
    sarima.py                      # SARIMA -> Holt-Winters -> naive drift tiered fit
    nnar.py                        # neural net on SARIMA residuals
    metrics.py                     # RMSE/MAE/MAPE, hybrid recombination
    pipeline.py                    # per-disease orchestration + auto-select safeguard
    serialization.py               # (de)serialization for session storage
  charts/figures.py               # every Plotly figure builder
  ui/
    components.py                  # small reusable Dash components
    layout.py                      # build_layout() -- the full page tree
  callbacks/
    data_callbacks.py              # file upload -> normalize -> validate -> combine
    view_callbacks.py              # source labels, lazy forecasts, exports, aggregate views
tests/                           # pytest regression suite
```

### Why it's split this way

This used to be a single 1,415-line file. Four functions had grown too complex
(radon cyclomatic complexity 11–21, grade C/D): `load_data`,
`parse_surveillance_xlsx`, `update_hybrid_section`, and `run_hybrid_pipeline`.
Each is now an orchestrator calling single-purpose helpers. The current
complexity report remains grade A on average; the few grade-C functions are
bounded callback, summary-rendering, and table-extraction orchestrators.

The `app_instance.py` split exists specifically to avoid a circular import:
`layout.py` and `callbacks/` both need the same `app` object, but if `app.py`
imported both of them to wire things up, and they in turn imported `app` back
from `app.py`, that's a cycle. Pulling the bare `Dash(...)` construction into
its own tiny module lets everyone import it one-directionally.

## Local development

```bash
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:8050`. Override host/port/debug via environment
variables if needed:

```bash
HOST=0.0.0.0 PORT=9000 DASH_DEBUG=false python app.py
```

## Running tests

```bash
pip install -r requirements-dev.txt
pytest tests/ -v
```

## Supported uploads and date conventions

CSV and XLSX uploads may use `year`/`month`, `year`/`week`, or a supported date
column such as `date`, `report_date`, or `reporting_period`. Before uploading,
select how ambiguous numeric dates should be interpreted: day first, month
first, or year first. ISO dates, timestamps, textual dates/months, and Excel
date serials are recognized automatically. Daily and weekly records are summed
to monthly totals before validation and modeling.

The specialized DOH/PIDSR week-by-year workbook layout remains supported. A
flat, row-based XLSX sheet is used as a fallback when the specialized layout is
not present. In a week-by-year workbook, every worksheet with a usable
`Morbidity Week` table is imported and its sheet name becomes the disease
label; the original seven names are not an upload whitelist.

A parsed upload first appears in **Upload summary** with its full validated disease list.
Only clicking **Use these N diseases** replaces the active disease catalog for that
browser session. Until confirmation, the previous session data (or sample) stays active.
A replacement upload supersedes the pending candidate; reset clears it, and refresh
discards unconfirmed data. Arbitrary labels, including PDF/ICD-10 categories, remain allowed. Disease selectors, charts, summaries, forecasts, and reporting years
are rebuilt from the uploaded values. Use **Reset to sample data** to erase the
active upload from the session and restore the seven synthetic examples.
Blank/invalid disease labels and all other rejected rows are reported visibly
in the upload status and summary.

Forecasting has a stricter contract than upload: each disease needs at least
72 consecutive, explicitly observed monthly rows. An absent month is treated
as unknown reporting—not zero cases—and blocks the forecast with a visible
reason. Two expanding rolling-origin folds select between SARIMA-only and
SARIMA+residual-MLP (NNAR) using unrounded WAPE. Hybrid must improve that score
by at least 1.00 percentage point; otherwise the simpler SARIMA-only candidate
is retained. All-zero selection windows use MAE because WAPE is undefined.
Seasonal naive is displayed
as a holdout benchmark; it is not selectable and is not drawn as a production
forecast. The chosen thesis model is then measured on a separate untouched
12-month holdout before the production refit. Dashboard RMSE, MAE, MAPE, and
WAPE are therefore holdout metrics, not claims about unknown future accuracy.
MAPE excludes zero-actual months and displays its denominator coverage.
The shaded forecast region is a historical maximum-absolute-error band, not a
validated guarantee of 95% future coverage.

## Converting text-based PDF tables

PDF extraction runs offline rather than inside the dashboard request path:

```bash
python -m dashboard.data.pdf_converter source.pdf converted.csv --date-convention day-first
```

Use an `.xlsx` destination instead of `.csv` when desired. The command writes
the converted file and a neighboring `<output>.report.json`. Review the totals,
rejected tables, scope warnings, dashboard-compatible disease list, and source
PDF before uploading the converted file. The canonical conversion and the
dashboard preserve all valid disease categories. Do not upload when the report says
`"dashboard_ready": false`; resolve its `dashboard_blockers` first.
Scanned PDFs are not supported because this converter deliberately does not
perform OCR.

## Deployment

The Dash/Flask **development server** (`app.run()`) is single-threaded and
not meant for production traffic. Everything below runs the app through
**gunicorn** instead, targeting `app:server` — the plain Flask WSGI app that
`dashboard/app_instance.py` exposes (`server = app.server`).

Note on state: session data lives in the browser (`dcc.Store(storage_type=
"session")`), not on the server, so it's safe to run multiple gunicorn
workers — no session affinity / sticky-sessions requirement.

### Option A — plain gunicorn on a VM

```bash
pip install -r requirements.txt
gunicorn app:server --bind 0.0.0.0:8050 --workers 1 --timeout 600
```

Put this behind nginx/Caddy for TLS termination in front of it, as usual for
any Flask app. A systemd unit or `tmux`/`screen` session keeps it running
after you disconnect.

### Option B — Docker

```bash
docker build -t antipolo-surveillance .
docker run -p 8050:8050 antipolo-surveillance
```

The included `Dockerfile` installs dependencies, copies the app, and runs one
Gunicorn worker with a 600-second timeout. `PORT` defaults to 8050 inside the
container; override with `-e PORT=9000` if needed (and adjust the `-p`
mapping to match).

### Option C — PaaS (Render, Railway, Heroku, Fly.io, etc.)

A `Procfile` is included:

```
web: gunicorn app:server --bind 0.0.0.0:$PORT --workers 1 --timeout 600
```

Most buildpack-based platforms auto-detect this and the `requirements.txt`,
and inject their own `$PORT` — no code changes needed. For Render
specifically: choose "Web Service", point it at this repo, and it will use
the `Procfile` automatically (or set the start command to the line above
manually if it doesn't auto-detect).

### Environment variables (all optional, all have sensible defaults)

| Variable     | Default     | Used by                                                                     |
| ------------ | ----------- | --------------------------------------------------------------------------- |
| `HOST`       | `127.0.0.1` | `app.py` (dev server only; gunicorn's `--bind` controls this in production) |
| `PORT`       | `8050`      | `app.py` (dev server) and the `Procfile`/`Dockerfile` (production)          |
| `DASH_DEBUG` | `true`      | `app.py` (dev server only — never set this true in production)              |
| `LOG_LEVEL`  | `INFO`      | `dashboard/logging_config.py`                                               |

### Things to check before deploying for real (not yet done in this repo)

- **Data persistence across deploys**: uploaded data lives only in the
  browser session, not a database. If you need uploads to persist across
  server restarts or be shared between users, that's a real architecture
  change (add a database or object storage), not a config tweak.
- **HTTPS**: gunicorn doesn't terminate TLS itself — put it behind a reverse
  proxy (nginx/Caddy) or rely on your PaaS's built-in TLS.
- **Health checks**: `/healthz` returns a lightweight 200 response for platform
  probes and container health checks.
- **Uploads**: `.csv` and `.xlsx` uploads are limited to 10 MB. CSV files are
  limited to 100,000 rows; workbooks also have sheet, dimension, and cell limits.
- **Secrets**: there currently aren't any (no API keys, no auth), but if you
  add any, use environment variables, never commit them.

### Historical reference and live benchmark

**Historical reference MAPE: 32.22%** is a fixed external/thesis reference,
not computed from the active dataset. See the thesis manuscript for its source.
**Seasonal-naive holdout MAPE/WAPE** is computed separately for each disease
and active dataset by copying the previous year's monthly observations into
the same untouched 12-month holdout. MAPE excludes zero-actual months; WAPE
uses the sum of absolute actual cases as its denominator. Undefined scores
are shown as N/A. The UI displays MAPE first, then WAPE, separated by a slash.
These are distinct references, shown side by side with neutral styling; they
are not merged, averaged, ranked against each other, or used to select a model.
Seasonal naive remains a diagnostic benchmark, not a production candidate.

Current evidence, exact UI wording, verification output, and all outstanding
thesis decisions are consolidated in [THESIS_READINESS.md](THESIS_READINESS.md).
