"""
The master per-disease pipeline: rolling model selection -> untouched holdout
evaluation -> production refit -> historical error band -> packaged result.

The original `run_hybrid_pipeline` was a single 76-line function (radon
cyclomatic complexity 11, grade C) that inlined both the backtest leg and the
production leg. Splitting them into `_run_backtest_leg` and
`_run_production_leg` means each one can be read (and tested) as "fit SARIMA,
extract residuals, fit NNAR, combine" without the other leg's code in the way,
and `run_hybrid_pipeline` itself is now just the orchestration: call backtest,
decide which model wins, call production, assemble the result.
"""

import numpy as np
import pandas as pd

from dashboard.config import (
    HOLDOUT_MONTHS, FORECAST_MONTHS, SELECTION_FOLDS, HYBRID_MIN_WAPE_GAIN_PP,
)
from dashboard.logging_config import get_logger
from dashboard.modeling.series_utils import get_disease_series, train_test_split_series
from dashboard.modeling.sarima import run_arima
from dashboard.modeling.nnar import run_nnar
from dashboard.modeling.metrics import hybrid_forecast, compute_metrics

logger = get_logger(__name__)


def _detect_data_source(df: pd.DataFrame, disease: str) -> str:
    """'real' if any row for this disease came from an upload, else 'mock'."""
    disease_rows = df[df["disease"] == disease]
    has_real = "source" in disease_rows.columns and (disease_rows["source"] == "real").any()
    return "real" if has_real else "mock"


def _run_backtest_leg(series: pd.Series, holdout: int) -> dict:
    """Forecast one window and score two thesis candidates plus an internal benchmark."""
    train, test = train_test_split_series(series, holdout=holdout)

    fitted_tr, fc_test, _, _, tier_bt, notes_bt = run_arima(train, forecast_steps=holdout)
    residuals_tr = (train - fitted_tr).dropna()
    _, nnar_resid_test, notes_nnar_bt = run_nnar(residuals_tr, forecast_steps=holdout, forecast_index=fc_test.index)

    test_sarima_only = fc_test.clip(lower=0)
    test_hybrid = hybrid_forecast(fc_test, nnar_resid_test)
    seasonal_values = np.resize(train.iloc[-12:].to_numpy(dtype=float), holdout)
    test_seasonal_naive = pd.Series(seasonal_values, index=test.index).clip(lower=0)

    return {
        "test": test,
        "test_sarima_only": test_sarima_only,
        "test_hybrid": test_hybrid,
        "test_seasonal_naive": test_seasonal_naive,
        "metrics": _score_aligned(test, test_hybrid),
        "sarima_only_metrics": _score_aligned(test, test_sarima_only),
        "seasonal_naive_metrics": _score_aligned(test, test_seasonal_naive),
        "tier": tier_bt,
        "warnings": [f"[backtest SARIMA] {n}" for n in notes_bt] + [f"[backtest NNAR] {n}" for n in notes_nnar_bt],
    }


def _validate_observation_coverage(df: pd.DataFrame, disease: str, required_months: int) -> None:
    rows = df[df["disease"] == disease].copy()
    if rows.empty:
        raise ValueError(f"No observations are available for '{disease}'.")
    observed = pd.PeriodIndex(pd.to_datetime(rows["date"]), freq="M").unique().sort_values()
    expected = pd.period_range(observed.min(), observed.max(), freq="M")
    missing = expected.difference(observed)
    if len(missing):
        raise ValueError(
            f"'{disease}' is missing {len(missing)} month(s) inside its observed range. "
            "Forecasting is blocked because missing reports cannot be assumed to mean zero cases."
        )
    if len(observed) < required_months:
        raise ValueError(
            f"'{disease}' has {len(observed)} complete observed months; need at least {required_months} "
            "for rolling model selection plus an untouched holdout."
        )


def _aggregate_fold_metrics(folds: list[dict], prediction_key: str) -> dict:
    for fold in folds:
        if not fold["test"].index.equals(fold[prediction_key].index):
            raise ValueError(f"Forecast dates do not align with actual dates for '{prediction_key}'.")
    actual = np.concatenate([fold["test"].to_numpy(dtype=float) for fold in folds])
    predicted = np.concatenate([fold[prediction_key].to_numpy(dtype=float) for fold in folds])
    return compute_metrics(actual, predicted)


def _selection_score(metrics: dict) -> float:
    """WAPE is the preregistered selection metric; MAE handles all-zero windows."""
    return metrics["wape"] if metrics["wape"] is not None else metrics["mae"]


def _score_aligned(actual: pd.Series, predicted: pd.Series) -> dict:
    """Score only forecasts whose dates exactly match their actual observations."""
    if not actual.index.equals(predicted.index):
        raise ValueError("Forecast dates do not align with actual dates.")
    return compute_metrics(actual.to_numpy(dtype=float), predicted.to_numpy(dtype=float))


def _historical_error_band(final_forecast: pd.Series, errors: np.ndarray) -> tuple[pd.Series, pd.Series, str]:
    """Historical maximum-absolute-error band for the selected forecast path."""
    absolute = np.abs(np.asarray(errors, dtype=float))
    n = len(absolute)
    quantile = min(1.0, np.ceil((n + 1) * 0.95) / n)
    radius = float(np.quantile(absolute, quantile, method="higher"))
    lower = (final_forecast - radius).clip(lower=0)
    upper = final_forecast + radius
    method = (
        f"Historical max-absolute-error band ({n} rolling/holdout errors; "
        f"radius {radius:.2f} cases; future coverage not validated)"
    )
    return lower, upper, method


def _run_production_leg(series: pd.Series, forecast_steps: int) -> dict:
    """Refits on the FULL series and forecasts `forecast_steps` real months ahead."""
    fitted_full, fc_future, _ci_lo, _ci_hi, tier_prod, notes_prod = run_arima(series, forecast_steps=forecast_steps)
    residuals_full = (series - fitted_full).dropna()
    nnar_fitted_full, nnar_resid_future, notes_nnar_prod = run_nnar(
        residuals_full, forecast_steps=forecast_steps, forecast_index=fc_future.index
    )
    return {
        "fitted": fitted_full,
        "residuals": residuals_full,
        "nnar_fitted": nnar_fitted_full,
        "sarima_forecast": fc_future.clip(lower=0),
        "hybrid_forecast": hybrid_forecast(fc_future, nnar_resid_future),
        "tier": tier_prod,
        "warnings": [f"[production SARIMA] {n}" for n in notes_prod] + [f"[production NNAR] {n}" for n in notes_nnar_prod],
    }


def run_hybrid_pipeline(df: pd.DataFrame, disease: str,
                         holdout: int = HOLDOUT_MONTHS,
                         forecast_steps: int = FORECAST_MONTHS,
                         selection_folds: int = SELECTION_FOLDS) -> dict:
    """
    Runs the full hybrid SARIMA+NNAR pipeline for one disease:
      1. Select SARIMA-only or hybrid using expanding rolling-origin folds.
      2. Evaluate that preselected model on an untouched final holdout.
      3. Refit on everything and forecast the real future.
      4. Build a selected-model historical error band from prior errors.
    """
    if selection_folds < 1:
        raise ValueError("At least one rolling selection fold is required.")
    required_months = 36 + holdout * (selection_folds + 1)
    _validate_observation_coverage(df, disease, required_months)
    series = get_disease_series(df, disease)

    data_source = _detect_data_source(df, disease)
    pre_evaluation = series.iloc[:-holdout]
    first_fold_end = len(pre_evaluation) - holdout * (selection_folds - 1)
    selection_legs = [
        _run_backtest_leg(pre_evaluation.iloc[:first_fold_end + fold * holdout], holdout)
        for fold in range(selection_folds)
    ]
    selection_metrics = {
        "hybrid": _aggregate_fold_metrics(selection_legs, "test_hybrid"),
        "sarima_only": _aggregate_fold_metrics(selection_legs, "test_sarima_only"),
    }
    selection_metric = "wape" if selection_metrics["sarima_only"]["wape"] is not None else "mae"
    sarima_score = _selection_score(selection_metrics["sarima_only"])
    hybrid_score = _selection_score(selection_metrics["hybrid"])
    selection_threshold = HYBRID_MIN_WAPE_GAIN_PP if selection_metric == "wape" else 0.0
    selected_model = (
        "hybrid" if sarima_score - hybrid_score >= selection_threshold and hybrid_score < sarima_score
        else "sarima_only"
    )

    evaluation = _run_backtest_leg(series, holdout)
    logger.info("disease=%s data_source=%s selected_model=%s hybrid_score=%.2f sarima_score=%.2f",
                disease, data_source, selected_model,
                _selection_score(selection_metrics["hybrid"]),
                _selection_score(selection_metrics["sarima_only"]))

    production = _run_production_leg(series, forecast_steps)

    forecast_by_model = {
        "hybrid": production["hybrid_forecast"],
        "sarima_only": production["sarima_forecast"],
    }
    metrics_by_model = {
        "hybrid": evaluation["metrics"],
        "sarima_only": evaluation["sarima_only_metrics"],
    }
    prediction_key_by_model = {
        "hybrid": "test_hybrid",
        "sarima_only": "test_sarima_only",
    }
    final_forecast = forecast_by_model[selected_model]
    final_metrics = metrics_by_model[selected_model]
    selected_key = prediction_key_by_model[selected_model]
    calibration_errors = np.concatenate([
        *(fold["test"].to_numpy(dtype=float) - fold[selected_key].to_numpy(dtype=float)
          for fold in selection_legs),
        evaluation["test"].to_numpy(dtype=float) - evaluation[selected_key].to_numpy(dtype=float),
    ])
    ci_lower, ci_upper, interval_method = _historical_error_band(final_forecast, calibration_errors)
    warnings_log = []
    for index, fold in enumerate(selection_legs, start=1):
        warnings_log.extend(f"[selection fold {index}] {warning}" for warning in fold["warnings"])
    warnings_log.extend(f"[untouched holdout] {warning}" for warning in evaluation["warnings"])
    warnings_log.extend(production["warnings"])
    if warnings_log:
        logger.warning("disease=%s produced %d model warning(s): %s", disease, len(warnings_log), warnings_log)

    return {
        "series": series,
        "sarima_fitted": production["fitted"],
        "residuals": production["residuals"],
        "nnar_fitted": production["nnar_fitted"],
        "sarima_forecast": production["sarima_forecast"],
        "hybrid_forecast": production["hybrid_forecast"],
        "final_forecast": final_forecast,
        "ci_lower": ci_lower,
        "ci_upper": ci_upper,
        "test_actual": evaluation["test"],
        "test_sarima_only": evaluation["test_sarima_only"],
        "test_hybrid": evaluation["test_hybrid"],
        "metrics": evaluation["metrics"],
        "sarima_only_metrics": evaluation["sarima_only_metrics"],
        "final_metrics": final_metrics,
        "baseline_metrics": evaluation["seasonal_naive_metrics"],
        "selection_metrics": selection_metrics,
        "selection_metric": selection_metric,
        "selection_threshold": selection_threshold,
        "selection_tiers": [fold["tier"] for fold in selection_legs],
        "evaluation_tier": evaluation["tier"],
        "selected_model": selected_model,
        "data_source": data_source,
        "model_tier": production["tier"],
        "interval_method": interval_method,
        "evaluation_window": f"{evaluation['test'].index.min():%Y-%m} to {evaluation['test'].index.max():%Y-%m}",
        "selection_folds": selection_folds,
        "warnings_log": warnings_log,
    }
